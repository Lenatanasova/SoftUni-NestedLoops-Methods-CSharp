﻿namespace _04.CalculateRectangleArea
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int width = int.Parse(Console.ReadLine());
            int lenght = int.Parse(Console.ReadLine());
            int area = CalculateArea(width, lenght);
            Console.WriteLine(area);

            
        }

        static int CalculateArea (int a, int b)
        {
            return a * b;
        }
    }
}
