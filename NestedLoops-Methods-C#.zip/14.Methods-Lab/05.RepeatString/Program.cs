﻿using System.ComponentModel;

namespace _05.RepeatString
{

    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int count = int.Parse(Console.ReadLine());

            string result = RepeatString(input, count);

            Console.WriteLine(result);
        }

        static string RepeatString(string text, int times)
        {

            string result = "";
            for (int i = 0; i < times; i++) 
            {
              result+= text;
            }

            return result;
        }
    }
}
