﻿
//Write a program to print a table, representing a building:
//•	Reads two integer numbers from the console: floors count and estates count per floor
//•	Identifiers consist of: { type}{ floor} { number}, e.g.L65, A12, O24
//•	Odd floors hold apartments (type A), e.g. A10, A11, A12, …
//•	Even floors hold offices (type O), e.g. O20, O21, O22, …
//•	The last floor holds large apartments (type L), e.g. L60, L61, L62

int floor = int.Parse(Console.ReadLine());
int estate = int.Parse(Console.ReadLine());

for (int row = floor; row >= 1; row--)
{
    for (int col = 0; col < estate; col++)
    {
        if (row == floor)
        {
            Console.Write($"L{row}{col} ");
        }
        else if (row % 2 == 1)
        {
            Console.Write($"A{row}{col} ");
        }
        else
        {
            Console.Write($"O{row}{col} ");
        }
       
    }
    Console.WriteLine();
}

