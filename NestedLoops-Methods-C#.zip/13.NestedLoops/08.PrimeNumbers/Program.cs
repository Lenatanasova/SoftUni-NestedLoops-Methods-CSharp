﻿
//Write a program that:
//•	Reads two integer numbers: start of the range and end of the range
//•	Print all prime numbers in given range
//Hint: A prime number is a positive integer greater than 1 that has exactly two distinct positive divisors: 1 and itself.

int startNum = int.Parse(Console.ReadLine());
int endNum = int.Parse(Console.ReadLine());

for (int num = startNum; num <= endNum; num++)
{
    bool isPrime = true;
    for (int i = 2; i < num; i++)
    {
        if (num % i == 0)
        {
            isPrime = false;
        }
    }
    if (isPrime)
    {
        Console.Write(num + " ");
    }
}