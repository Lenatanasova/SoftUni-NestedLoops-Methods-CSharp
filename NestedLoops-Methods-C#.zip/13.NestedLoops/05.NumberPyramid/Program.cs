﻿int n = int.Parse(Console.ReadLine());

int currentNum = 1;
int row = 1;
while (currentNum <= n)
{
    for (int col = 1; col <= row && currentNum <= n; col++)
    {
        Console.Write($"{currentNum} ");
        currentNum++;
    }
    row++;
    Console.WriteLine( );
}