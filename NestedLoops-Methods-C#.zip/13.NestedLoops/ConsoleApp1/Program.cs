﻿//•	Reads an integer number N from the console
//•	Prints the numbers from N to 1, each on separate line

int n = int.Parse(Console.ReadLine());

//for (int i = n; i >= 1; i--)
//{
//    Console.WriteLine(i);
//}
while ( n != 0 )
{
    Console.WriteLine( n );
    n--;
}