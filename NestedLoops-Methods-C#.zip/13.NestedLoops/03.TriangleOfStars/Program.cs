﻿int n = int.Parse(Console.ReadLine());

for (int i = 1; i <= n; i++)
{
    for (int star = 1; star <= i; star++)
    {
        Console.Write("*");
    }
    Console.WriteLine();
}