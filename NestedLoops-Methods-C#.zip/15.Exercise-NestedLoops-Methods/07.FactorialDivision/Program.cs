﻿namespace _07.FactorialDivision
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number1 = int.Parse(Console.ReadLine());
            int number2 = int.Parse(Console.ReadLine());

            int firstFactorial = FindFactorial(number1);
            int secondFactorial = FindFactorial(number2);

            Console.WriteLine(firstFactorial / secondFactorial);
            
        }
        
        static int FindFactorial(int num)
        {
            int factorial = 1;

            for (int i = num; i >= 1; i--)
            {
                factorial = i * factorial;
            }
            return factorial;
        }
    }
}
