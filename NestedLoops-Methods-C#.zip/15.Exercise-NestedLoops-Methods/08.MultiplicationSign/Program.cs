﻿using System.ComponentModel;
using System.Reflection;

namespace _08.MultiplicationSign
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int num3 = int.Parse(Console.ReadLine());

            PrintMultiplicationSign(num1, num2, num3);
        }

        static void PrintMultiplicationSign(int num1, int num2, int num3)
        {
            int product = num1 * num2 * num3;
            if (product < 0)
            {
                Console.WriteLine("negative");
            }
            else if (product == 0)
            {
                Console.WriteLine("zero");
            }
            else
            {
                Console.WriteLine("positive");
            }
        }
    }
}
