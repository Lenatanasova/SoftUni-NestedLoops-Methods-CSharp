﻿using System;

namespace _10.PassValid
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string password = Console.ReadLine();

            if (!CheckIfPassBetweenSixAndTenChars(password))
            {
                Console.WriteLine("Password must be between 6 and 10 characters");
            }
            if (!CheckPassHasOnlyLettersAndDigits(password))
            {
                Console.WriteLine("Password must consist only of letters and digits");
            }
            if (!CheckPassMinimumDigitCount(password))
            {
                Console.WriteLine("Password must have at least 2 digits");
            }
            if(CheckIfPassBetweenSixAndTenChars(password) && CheckPassHasOnlyLettersAndDigits(password) && CheckPassMinimumDigitCount(password))
            {
                Console.WriteLine("Password is valid");
            }
        }

        static bool CheckIfPassBetweenSixAndTenChars(string pass)
        {
            if (pass.Length >= 6 && pass.Length <= 10)
            {
                return true;
            }
            return false;
        }

        static bool CheckPassHasOnlyLettersAndDigits(string pass)
        {
            for (int i = 0; i < pass.Length; i++)
            {
                char CurrChar = pass[i];

                if (!char.IsLetterOrDigit(CurrChar))
                {
                    return false;
                }
            }
            return true;
        }
        static bool CheckPassMinimumDigitCount(string pass)
        {
            int counter = 0;
            for (int i = 0; i < pass.Length; i++)
            {
                char currChar = pass[i];
                if (char.IsDigit(currChar))
                {
                    counter++;
                    if (counter >= 2)
                    {
                        return true;
                    }
                }

            }
            return false;
        }
    }
}
