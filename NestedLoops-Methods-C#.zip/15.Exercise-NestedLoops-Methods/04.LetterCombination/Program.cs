﻿namespace _04.LetterCombination
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char start = char.Parse(Console.ReadLine());
            char end = char.Parse(Console.ReadLine());
            char excluded = char.Parse(Console.ReadLine());

            int counter = 0;
            for (char i = start; i <= end; i++)
            {
                for (char j = start; j <= end; j++)
                {
                    for (char k = start; k <= end; k++)
                    {
                        if (k == excluded || j == excluded || i == excluded)
                        {
                            continue;
                        }

                        Console.Write($"{i}{j}{k} ");
                        counter++;
                        

                    }
                }
            }
            Console.WriteLine();
            Console.WriteLine(counter);

        }
    }
}
