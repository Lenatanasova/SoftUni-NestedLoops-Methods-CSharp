﻿using System.Collections.Generic;

namespace _15.Exercise_NestedLoops_Methods
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());

            for (int i = 2; i <= n; i+=2 )
            {
                for (int j = 1; j <= n; j+=2 )
                {
                    int productOfTwo = i * j;

                    Console.Write($"{i}{j}{productOfTwo} ");
                }
            }

        }
    }
}
